from django.contrib import admin
from django.urls import path
from .views import home ,Rabbits,natural,card,bigdata,machine1,Analysis,Django2,Python5,deep5,customerregistrationView
from django.contrib.auth import views as auth_views
from django.urls import path
from .views import logout_view

from django.conf import settings
from django.conf.urls.static import static
from django.contrib.auth import views as auth_views
from .forms import Loginform

urlpatterns = [
    
    path('', home , name = 'home'),
    path('Rabbits/' , Rabbits , name = 'Rabbits'),
    path('natural/' , natural , name = 'natural'),
    path('card/' , card , name = 'card'),
    path('card/' , card , name = 'card'),
    path('bigdata/' , bigdata , name = 'bigdata'),
    path('machine1/' , machine1 , name = 'machine1'),
    path('Analysis/' , Analysis , name = 'Analysis'),
    path('Django2/' , Django2 , name = 'Django2'),
    path('Python5/' , Python5 , name = 'Python5'),
    path('deep5/' , deep5 , name = 'deep5'),
    path('accounts/login/', auth_views.LoginView.as_view(template_name='login.html', authentication_form=Loginform), name='login'),
    path('registration/', customerregistrationView.as_view(), name='customerregistration'),
    path('logout/', logout_view, name='logout'),
]