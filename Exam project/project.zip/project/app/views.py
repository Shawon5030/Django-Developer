from django.shortcuts import render

from django.views import View
from .forms import customerregistrationform
from django.contrib import messages

# Create your views here.
def home(request):
    return render(request ,'home.html')
def Rabbits(request):
    return render(request , 'Rabbits.html')
def natural(request):
    return render(request , 'natural.html')
def card(request):
    return render(request , 'card.html')
def bigdata(request):
    return render(request , 'bigdata.html')
def machine1(request):
    return render(request , 'machine1.html')
def Analysis(request):
    return render(request , 'Analysis.html')
def Django2(request):
    return render(request , 'Django2.html')
def Python5(request):
    return render(request , 'Python5.html')
def deep5(request):
    return render(request , 'deep5.html')

from .forms import customerregistrationform
from django.views import View
from django.contrib.auth import logout
from django.shortcuts import redirect

def logout_view(request):
    logout(request)
    # Redirect to a page after logout, for example, the homepage.
    return redirect('home')

class customerregistrationView(View):
 def get(self , request):
  form = customerregistrationform()
  return render(request, 'customerregistration.html', {'form':form})
 
 def post(self,request):
  form = customerregistrationform(request.POST)
  if form.is_valid():
   messages.success(request, 'Congratulations Registration Done')
   form.save()
  return render(request, 'customerregistration.html', {'form':form})
